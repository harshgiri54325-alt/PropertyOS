# PropertyOS MVP v3

Real-estate SaaS starter with:
- Supabase email/password authentication
- PostgreSQL schema + Row Level Security
- Properties CRUD
- Leads CRM
- Site-visit-ready schema
- Razorpay recurring subscription checkout
- Solo ₹499 / Pro ₹1,499 / Agency ₹4,999 plan UI

## Setup

1. Create a Supabase project.
2. Run `supabase-schema.sql` in the Supabase SQL Editor.
3. Copy `.env.example` to `.env.local` and add Supabase keys.
4. Create three Razorpay recurring plans and put their IDs in:
   - RAZORPAY_PLAN_SOLO
   - RAZORPAY_PLAN_PRO
   - RAZORPAY_PLAN_AGENCY
5. Add Razorpay test/live keys.
6. `npm install`
7. `npm run dev`

Supabase Auth uses cookie-based sessions and RLS for row-level authorization.
Razorpay subscriptions require a Plan before a Subscription; configure webhooks before production so subscription lifecycle changes can update account status.

Do not commit `.env.local` or secret keys.

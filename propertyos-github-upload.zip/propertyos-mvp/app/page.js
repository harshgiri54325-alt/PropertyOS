"use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "../lib/supabase/client";
import { useRouter } from "next/navigation";

const emptyProperty = { title:"", property_type:"Apartment", transaction_type:"sale", price:"", area:"", bedrooms:"", location:"", status:"available", description:"" };
const emptyLead = { name:"", phone:"", requirement:"", budget:"", location:"", status:"new", next_follow_up:"", notes:"" };

export default function Home() {
  const supabase = createClient();
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [properties, setProperties] = useState([]);
  const [leads, setLeads] = useState([]);
  const [tab, setTab] = useState("dashboard");
  const [property, setProperty] = useState(emptyProperty);
  const [lead, setLead] = useState(emptyLead);
  const [showProperty, setShowProperty] = useState(false);
  const [showLead, setShowLead] = useState(false);
  const [loading, setLoading] = useState(true);

  async function load() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return router.replace("/auth");
    setUser(user);
    const [p, l] = await Promise.all([
      supabase.from("properties").select("*").order("created_at", { ascending:false }),
      supabase.from("leads").select("*").order("created_at", { ascending:false })
    ]);
    setProperties(p.data || []);
    setLeads(l.data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function addProperty(e) {
    e.preventDefault();
    const { error } = await supabase.from("properties").insert({
      ...property, user_id:user.id,
      price: property.price ? Number(property.price) : null,
      area: property.area ? Number(property.area) : null,
      bedrooms: property.bedrooms ? Number(property.bedrooms) : null
    });
    if (!error) { setShowProperty(false); setProperty(emptyProperty); load(); }
  }

  async function addLead(e) {
    e.preventDefault();
    const { error } = await supabase.from("leads").insert({
      ...lead, user_id:user.id,
      budget: lead.budget ? Number(lead.budget) : null,
      next_follow_up: lead.next_follow_up || null
    });
    if (!error) { setShowLead(false); setLead(emptyLead); load(); }
  }

  async function removeProperty(id) { await supabase.from("properties").delete().eq("id", id); load(); }
  async function removeLead(id) { await supabase.from("leads").delete().eq("id", id); load(); }

  async function logout() { await supabase.auth.signOut(); router.replace("/auth"); }

  const stats = useMemo(() => ({
    active: properties.filter(x => x.status === "available").length,
    leads: leads.length,
    visits: 0,
    followups: leads.filter(x => x.next_follow_up).length
  }), [properties, leads]);

  if (loading) return <main className="loading">Loading PropertyOS…</main>;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">PropertyOS</div>
        <button className={tab==="dashboard"?"nav active":"nav"} onClick={()=>setTab("dashboard")}>Dashboard</button>
        <button className={tab==="properties"?"nav active":"nav"} onClick={()=>setTab("properties")}>Properties</button>
        <button className={tab==="leads"?"nav active":"nav"} onClick={()=>setTab("leads")}>Leads CRM</button>
        <button className={tab==="billing"?"nav active":"nav"} onClick={()=>setTab("billing")}>Plans & Billing</button>
        <div className="side-bottom">
          <div className="user-mini">{user?.email}</div>
          <button className="nav" onClick={logout}>Log out</button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div><div className="eyebrow">REAL ESTATE OPERATING SYSTEM</div><h1>{tab==="dashboard"?"Good morning 👋":tab==="properties"?"Properties":tab==="leads"?"Leads CRM":"Plans & Billing"}</h1></div>
          <div className="actions">
            <button className="secondary" onClick={()=>setShowLead(true)}>+ Lead</button>
            <button className="primary" onClick={()=>setShowProperty(true)}>+ Property</button>
          </div>
        </header>

        {tab === "dashboard" && (
          <>
            <section className="stats">
              <Stat label="Active Properties" value={stats.active}/>
              <Stat label="New Leads" value={stats.leads}/>
              <Stat label="Site Visits" value={stats.visits}/>
              <Stat label="Follow-ups Due" value={stats.followups}/>
            </section>
            <section className="grid-2">
              <Panel title="Recent Properties">
                {properties.slice(0,5).map(p=><div className="row" key={p.id}><div><b>{p.title}</b><small>{p.location} · {p.transaction_type}</small></div><span>{p.price ? "₹"+Number(p.price).toLocaleString("en-IN") : "—"}</span></div>)}
                {!properties.length && <Empty text="Add your first property."/>}
              </Panel>
              <Panel title="Recent Leads">
                {leads.slice(0,5).map(l=><div className="row" key={l.id}><div><b>{l.name}</b><small>{l.requirement || "Requirement not added"}</small></div><span className="pill">{l.status}</span></div>)}
                {!leads.length && <Empty text="Add your first lead."/>}
              </Panel>
            </section>
          </>
        )}

        {tab === "properties" && <Panel title="All Properties"><div className="table-head"><span>Property</span><span>Location</span><span>Price</span><span>Status</span><span></span></div>{properties.map(p=><div className="table-row" key={p.id}><span><b>{p.title}</b><small>{p.bedrooms||"—"} BHK · {p.area||"—"} sq.ft</small></span><span>{p.location||"—"}</span><span>{p.price ? "₹"+Number(p.price).toLocaleString("en-IN"):"—"}</span><span className="pill">{p.status}</span><button className="danger" onClick={()=>removeProperty(p.id)}>Delete</button></div>)}{!properties.length&&<Empty text="No properties yet."/>}</Panel>}

        {tab === "leads" && <Panel title="Lead Pipeline"><div className="table-head"><span>Lead</span><span>Requirement</span><span>Budget</span><span>Status</span><span></span></div>{leads.map(l=><div className="table-row" key={l.id}><span><b>{l.name}</b><small>{l.phone||"No phone"}</small></span><span>{l.location||"—"} · {l.requirement||"—"}</span><span>{l.budget ? "₹"+Number(l.budget).toLocaleString("en-IN"):"—"}</span><span className="pill">{l.status}</span><button className="danger" onClick={()=>removeLead(l.id)}>Delete</button></div>)}{!leads.length&&<Empty text="No leads yet."/>}</Panel>}

        {tab === "billing" && <Billing/>}
      </main>

      {showProperty && <Modal title="Add Property" onClose={()=>setShowProperty(false)}><form onSubmit={addProperty} className="form-grid">{Object.entries(property).map(([k,v])=><input key={k} placeholder={k.replaceAll("_"," ")} value={v} onChange={e=>setProperty({...property,[k]:e.target.value})}/>) }<button className="primary full" type="submit">Save Property</button></form></Modal>}
      {showLead && <Modal title="Add Lead" onClose={()=>setShowLead(false)}><form onSubmit={addLead} className="form-grid">{Object.entries(lead).map(([k,v])=><input key={k} placeholder={k.replaceAll("_"," ")} value={v} onChange={e=>setLead({...lead,[k]:e.target.value})}/>) }<button className="primary full" type="submit">Save Lead</button></form></Modal>}
    </div>
  );
}

function Stat({label,value}){return <div className="stat"><small>{label}</small><strong>{value}</strong></div>}
function Panel({title,children}){return <section className="panel"><div className="panel-title"><h2>{title}</h2></div>{children}</section>}
function Empty({text}){return <div className="empty">{text}</div>}
function Modal({title,onClose,children}){return <div className="overlay"><div className="modal"><div className="modal-head"><h2>{title}</h2><button onClick={onClose}>×</button></div>{children}</div></div>}

function Billing(){
  const plans=[["Solo","₹499/month","50 properties · AI tools · CRM"],["Pro","₹1,499/month","Unlimited properties · automation · analytics"],["Agency","₹4,999/month","Team users · lead assignment · agency analytics"]];
  async function subscribe(plan){ window.location.href=`/api/create-subscription?plan=${encodeURIComponent(plan)}`; }
  return <div className="plans">{plans.map(([name,price,desc])=><div className="plan" key={name}><div><h2>{name}</h2><strong>{price}</strong><p>{desc}</p></div><button className="primary" onClick={()=>subscribe(name)}>Start subscription</button></div>)}<p className="muted">Payments use Razorpay Subscriptions. Configure Razorpay plan IDs and keys in your environment before going live.</p></div>
}

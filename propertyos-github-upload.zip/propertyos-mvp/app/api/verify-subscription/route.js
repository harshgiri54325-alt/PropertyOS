import crypto from "crypto";
import { NextResponse } from "next/server";
import { createClient } from "../../../lib/supabase/server";

export async function POST(request){
  const body=await request.json();
  const expected=crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
    .update(`${body.razorpay_payment_id}|${body.razorpay_subscription_id}`)
    .digest("hex");

  if(expected!==body.razorpay_signature) return NextResponse.json({ok:false,error:"Invalid signature"},{status:400});

  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  if(user){
    await supabase.from("profiles").update({
      razorpay_subscription_id: body.razorpay_subscription_id,
      subscription_status:"active"
    }).eq("id",user.id);
  }
  return NextResponse.json({ok:true});
}

import Razorpay from 'razorpay';
export async function POST(req){
  try{
    const {plan='pro'}=await req.json();
    const prices={solo:49900,pro:149900,agency:499900};
    if(!process.env.RAZORPAY_KEY_ID||!process.env.RAZORPAY_KEY_SECRET) return Response.json({error:'Razorpay keys are not configured. Add them to .env.local.'},{status:503});
    const amount=prices[plan]; if(!amount) return Response.json({error:'Invalid plan'},{status:400});
    const razorpay=new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});
    const order=await razorpay.orders.create({amount,currency:'INR',receipt:`propertyos_${Date.now()}`,notes:{plan}});
    return Response.json({order,keyId:process.env.RAZORPAY_KEY_ID});
  }catch(e){return Response.json({error:e.message},{status:500})}
}

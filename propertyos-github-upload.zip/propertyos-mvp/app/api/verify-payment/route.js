import crypto from 'crypto';
export async function POST(req){
  const {orderId,paymentId,signature}=await req.json();
  if(!process.env.RAZORPAY_KEY_SECRET) return Response.json({error:'Razorpay secret is not configured'},{status:503});
  const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET).update(`${orderId}|${paymentId}`).digest('hex');
  return Response.json({verified:crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(signature||''))});
}

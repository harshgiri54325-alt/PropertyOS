import { NextResponse } from "next/server";
import Razorpay from "razorpay";

const planMap = {
  Solo: process.env.RAZORPAY_PLAN_SOLO,
  Pro: process.env.RAZORPAY_PLAN_PRO,
  Agency: process.env.RAZORPAY_PLAN_AGENCY
};

export async function GET(request) {
  const plan = new URL(request.url).searchParams.get("plan");
  const planId = planMap[plan];
  if (!planId || !process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
    return NextResponse.json({ error: "Razorpay plan/key configuration missing." }, { status: 500 });
  }

  const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET
  });

  const subscription = await razorpay.subscriptions.create({
    plan_id: planId,
    total_count: 120,
    quantity: 1,
    customer_notify: 1
  });

  return NextResponse.redirect(
    new URL(`/billing/checkout?subscription_id=${subscription.id}&key_id=${process.env.RAZORPAY_KEY_ID}&plan=${encodeURIComponent(plan)}`, request.url)
  );
}

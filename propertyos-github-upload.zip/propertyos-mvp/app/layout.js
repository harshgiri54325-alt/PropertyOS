import './globals.css';
export const metadata={title:'PropertyOS',description:'AI-powered real estate workspace'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}

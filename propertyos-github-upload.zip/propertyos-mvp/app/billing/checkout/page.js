"use client";
import { useEffect } from "react";
import { useSearchParams } from "next/navigation";

export default function CheckoutPage(){
  const params = useSearchParams();
  const subId = params.get("subscription_id");
  const keyId = params.get("key_id");

  useEffect(()=>{
    if(!subId || !keyId) return;
    const script=document.createElement("script");
    script.src="https://checkout.razorpay.com/v1/checkout.js";
    script.onload=()=>{
      const rzp=new window.Razorpay({
        key:keyId,
        subscription_id:subId,
        name:"PropertyOS",
        description:"Real Estate SaaS subscription",
        theme:{color:"#111827"},
        handler: async (response)=>{
          const res=await fetch("/api/verify-subscription",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(response)});
          const data=await res.json();
          window.location.href=data.ok?"/?paid=1":"/?paid=0";
        }
      });
      rzp.open();
    };
    document.body.appendChild(script);
    return ()=>document.body.removeChild(script);
  },[subId,keyId]);

  return <main className="loading">Opening secure Razorpay checkout…</main>;
}
